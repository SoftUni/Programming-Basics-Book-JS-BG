
eval($.turtle());
$('#turtle').css('turtleScale', '2').css('turtleSpeed', '4');

function resetCanvas() {
    cg();
    home();
    $('#turtle').css('turtleScale', '2').css('turtleSpeed', '4');
}

$('#reset').click(function() {
    window.location.reload();
});

$('#justDraw').click(function() {
    cg();
    for (let index = 0; index < 4; index++) {
        $('#turtle').pen('blue', '5')
        .lt(30).fd(150)
        .lt(120).fd(150)
        .lt(120).fd(150);
    }
});

$('#hide').click(function() {
        $('#turtle').toggle();
        $(this).text(function(i, text) {
          return text === "Hide Turtle" ? "Show Turtle" : "Hide Turtle";
      });
});

$('#drawHexagon').click(function() {
    resetCanvas();
    for (let index = 0; index < 6; index++) {
        $('#turtle').pen('blue', '5').rt(60).fd(100);
    }
});

$('#drawStar').click(function() {
    resetCanvas();
    for (let index = 0; index < 5; index++) {
        $('#turtle').pen('green', '5').fd(180).lt(144);
    }
});

$('#drawSpiral').click(function() {
    resetCanvas();
    $('#turtle').css('turtleSpeed', '4');
    for (let index = 0; index < 30; index++) {
        $('#turtle').pen('green', '5').fd(index * 5).lt(60);
    }
});

$('#drawSun').click(function() {
    resetCanvas();
    $('#turtle').css('turtleSpeed', '5');
    for (let index = 0; index < 36; index++) {
        $('#turtle').pen('blue', '5').fd(200).lt(170);
    }
});

$('#drawTriangle').click(function() {
    resetCanvas();
    $('#turtle').css('turtleSpeed', '5');
    for (let p = 0; p < 3; p++) {
        for (let index = 0; index < 20; index++) {
        $('#turtle').pen('red', '5').lt(120).fd(index * 10);
        }
    }
});
